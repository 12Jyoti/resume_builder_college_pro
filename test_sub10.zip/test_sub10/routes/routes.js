module.exports = function(app,adminRouter)

 {
    
    var jwt = require('jsonwebtoken');
    var secret_key = 'SRCEukzwWJybZkUpHVdA5PtdkFvWPmddyUwtb2';
    var mainc = require('../controller/main');
    app.get('/', mainc.mainfn);
    app.post('/login', mainc.login);
    app.post('/signup', mainc.signup);
    app.get('/create-user-password', mainc.createUserPassword);
    app.get('/reset-user-Password', mainc.resetuserPassword);
    app.post('/savePassword', mainc.savePassword);
    app.post('/forgotPassword', mainc.forgotPassword);
    var OAuthLogin = require('../controller/OAuth');
    app.post('/auth/facebook', OAuthLogin.facebookLogin);
    var googleOAuthLogin = require('../controller/googleOAuth');
    app.post('/auth/google', googleOAuthLogin.googleLogin);
    adminRouter.use(function(req, res, next) {
        console.log("Line 21:", req.headers.authorization);
        var token = req.headers.authorization;
        jwt.verify(token, secret_key, function(err, decoded) {
            if (err) {
                res.status(400).json('Invalid Request');
            } else {
                req.decoded = decoded;
                next();
            }
        });
    });
    app.use('/adminApi', adminRouter);
}