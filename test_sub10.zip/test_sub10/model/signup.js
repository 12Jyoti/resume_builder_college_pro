var mongoose = require("mongoose");
var schema = mongoose.Schema;
var signupSchema = new schema({
    first_name: { type: String },
    last_name: { type: String },
    kind: { type: String },
    sub: { type: String },
    name: { type: String },
    given_name: { type: String },
    family_name: { type: String },
    email: { type: String },
    picture: { type: String },
    email_verified: { type: String },
    locale: { type: String },
    name: { type: String, require: true },
    mail: { type: String, require: true },
    cont: { type: String, require: true },
    password: { type: String },
    token: { type: String },
    resetToken: { type: String },
    OAuthID: { type: String },
    OAuthType: { type: String },
    tokenStatus: { type: Boolean },
    resetTokenStatus: { type: Boolean },
    created_at: { type: Date, default: Date.now }

});

exports.signupmodel = mongoose.model('signupmodel', signupSchema);