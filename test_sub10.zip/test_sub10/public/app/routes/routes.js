hexapot.config(function($stateProvider) {
    $stateProvider
        .state('home', {
            url: '/',
            templateUrl: '/partials/home.html',
            controller: 'loginController',
            resolve: {
                userBeforeLogin: userBeforeLogin
            }

        })
        .state('forgotPassword', {
            url: '/forgotPassword',
            templateUrl: '/partials/forgotPassword.html',
            controller: 'forgotPasswordController'
        })
        .state('dashboard', {
            
            url: '/dashboard',
            templateUrl: '/partials/dashboard.html',
            abstract: true,
            controller: 'dashboardController',
            resolve: {
                userAfterLogin: userAfterLogin
            }
        })
        .state('dashboard.home1', {
            url: '',
            templateUrl: '/partial/dashboard_home.html',

        })
        .state('dashboard.summery', {
            url: '/summery',
            templateUrl: '/partials/summery.html',
            controller: 'summeryController',

        })
        .state('dashboard.basic', {
            url: '/basic',
            templateUrl: '/partials/index.html',
            // controller: 'basicController',

        })
        .state('dashboard.experince', {
            url: '/experince',
            templateUrl: '/partials/experince.html',
            controller: 'experinceController',

        })
        .state('dashboard.project', {
            url: '/project',
            templateUrl: '/partials/projects.html',
            controller: 'projectController',

        })
        .state('dashboard.education', {
            url: '/education',
            templateUrl: '/partials/education.html',
            controller: 'educationController',

        })
        .state('dashboard.skills', {
            url: '/skills',
            templateUrl: '/partials/skills.html',
            controller: 'skillsController',

        })
        .state('dashboard.download', {
            url: '/download',
            templateUrl: '/partials/download.html',
            controller: 'downloadController',

        })
        .state('signup', {
            url: '/signup',
            templateUrl: '/partials/signup.html',
            controller: 'signupcontroller'
        })
        .state('createAdminPassword', {
            url: '/create-user-password/:token',
            templateUrl: '/partials/create_password.html',
            controller: 'createAdminPasswordController',
            resolve: {
                checkCreateUserPassword: checkCreateUserPassword
            }
        })
        .state('ReCreateAdminPassword', {
            url: '/reset-user-Password/:resetToken',
            templateUrl: '/partials/re_create_password.html',
            controller: 'ReCreateAdminPasswordController',
            resolve: {
                checkReCreateUserPassword: checkReCreateUserPassword
            }
        })

});

function checkCreateUserPassword($q, $http, $stateParams) {
    var deferred = $q.defer($http, $q, $stateParams);
    $http({
        method: 'get',
        url: '/create-user-password/?token=' + $stateParams.token
    }).then(function successCallback(response) {
        if (response.data.result) {
            deferred.resolve(response.data);
        } else {
            deferred.reject({ tokenExpired: true });
        }
    }, function errorCallback(error) {
        deferred.reject({ tokenExpired: true });
    });
    return deferred.promise;
}

function checkReCreateUserPassword($q, $http, $stateParams) {
    var deferred = $q.defer($http, $q, $stateParams);
    $http({
        method: 'get',
        url: '/reset-user-password/?resetToken=' + $stateParams.resetToken
    }).then(function successCallback(response) {
        if (response.data.result) {
            deferred.resolve(response.data);
        } else {
            deferred.reject({ resetTokenExpired: true });
        }
    }, function errorCallback(error) {
        deferred.reject({ resetTokenExpired: true });
    });
    return deferred.promise;
}

function userBeforeLogin($q, userAuth) {
    var deferred = $q.defer($q, userAuth);
    var currentUser = userAuth.getCurrentUser();
    access_token = currentUser ? currentUser.access_token : null;
    console.log("Line 75:", access_token);
    if (access_token) {
        deferred.reject({ session: true, role: 'admin' });
    } else {
        deferred.resolve();
    }
    return deferred.promise;
}

function userAfterLogin($q, userAuth) {
    var deferred = $q.defer();
    var currentUser = userAuth.getCurrentUser();
    access_token = currentUser ? currentUser.access_token : null;
    console.log("Line 75:", access_token);
    if (access_token) {
        deferred.resolve();
        // deferred.reject({ session: true, role: 'admin' });
    } else {
        deferred.reject({ session: false, role: 'admin' });
    }
    return deferred.promise;
}