hexapot.controller('signupcontroller', ['$scope', 'mainService','toaster', function($scope, mainService) {

    $scope.signup = function(signupdata) {
      
        console.log(signupdata);
        
        mainService.signup(signupdata)
            .then(function(response) {
                var user = {};
                user.access_token = response.token;
                userAuth.setCurrentUser(user);
                $state.go('dashboard.home1');

            })
            .catch(function(error) {

            })
    }
}])
hexapot.controller('forgotPasswordController', ['$scope', '$state', 'mainService', function($scope, $state, mainService) {

    $scope.forgotPassword = function(data) {
        mainService.forgotPassword(data)
            .then(function(response) {
                $state.go('home');
            })
            .catch(function(error) {
                $scope.errorMessage = error.message;
            });
    }
}])
hexapot.controller('createAdminPasswordController', ['$scope', '$state', '$stateParams', 'mainService', function($scope, $state, $stateParams, mainService) {


    $scope.savePassword = function(data) {
        console.log(data);
        if (data.confirmPassword == data.password) {
            data.token = $stateParams.token;
            mainService.savePassword(data)
                .then(function(response) {
                    $state.go('home');
                })
                .catch(function(error) {});
        } else {

        }

    }
}])
hexapot.controller('ReCreateAdminPasswordController', ['$scope', '$state', '$stateParams', 'mainService', function($scope, $state, $stateParams, mainService) {


    $scope.savePassword = function(data) {
        console.log(data);
        if (data.confirmPassword == data.password) {
            data.resetToken = $stateParams.resetToken;
            mainService.savePassword(data)
                .then(function(response) {
                    $state.go('home');
                })
                .catch(function(error) {});
        } else {

        }

    }
}])
hexapot.controller('loginController', ['$scope', '$auth', '$state', 'mainService', 'userAuth','toaster', function($scope, $auth, $state, mainService, userAuth,toaster) {

    $scope.login = function(data) {
        toaster.pop('success', 'login successful', 'welcome to resume builder');
        mainService.login(data)
            .then(function(response) {
                console.log(response);
                var user = {};
                user.access_token = response.token;
                userAuth.setCurrentUser(user);
                $state.go('dashboard.home1');
            })
            .catch(function(error) {

            });
    }

    $scope.authenticate = function(provider) {
        $auth.authenticate(provider)
        
        .then(function(response) {
            console.log("LIne 17:", response.data.token);
            var user = {};
            user.access_token = response.data.token;
            userAuth.setCurrentUser(user);
            $state.go('dashboard.home1');
        })
        .catch(function(error) {

        })
    };
}]);

hexapot.controller('dashboardController', ['$scope', '$state', 'userAuth', function($scope, $state, userAuth) {

    $scope.logOut = function() {
        userAuth.setCurrentUser(null);
        $state.go('home');
    }
}]);