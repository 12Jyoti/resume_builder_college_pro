var config = require('./OAuthConfig');
var request = require('request');
var mongoose = require('mongoose');

require('../model/registrationModel.js');
var registrationModel = mongoose.model('registrationModel');


exports.linkedinLogin = function(req, res) {
    var scope = ['r_basicprofile', 'r_fullprofile', 'r_emailaddress', 'r_network', 'r_contactinfo', 'rw_nus', 'rw_groups', 'w_messages'];
    app.get('/oauth/linkedin/callback', function(req, res) {
        Linkedin.auth.getAccessToken(res, req.query.code, req.query.state, function(err, results) {
            if ( err )
                return console.error(err);
     
            /**
             * Results have something like:
             * {"expires_in":5184000,"access_token":". . . ."}
             */
     
            console.log(results);
            return res.redirect('/dashboard');
        });
    });
    
}