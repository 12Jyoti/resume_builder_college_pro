module.exports = {
    FACEBOOK_SECRET: '',
    GOOGLE_SECRET: '',
    LINKEDIN_SECRET: '',
};