var config = require('./OAuthConfig');
var request = require('request');
var mongoose = require('mongoose');

require('../model/signup.js');
var signupmodel = mongoose.model('signupmodel');


exports.facebookLogin = function(req, res) {

    var fields = ['id', 'email', 'first_name', 'last_name', 'name', 'picture', 'gender'];
    var accessTokenUrl = 'https://graph.facebook.com/v3.3/oauth/access_token';
    var graphApiUrl = 'https://graph.facebook.com/v3.3/me?fields=' + fields.join(',');
    var params = {
        code: req.body.code,
        client_id: req.body.clientId,
        client_secret: config.FACEBOOK_SECRET,
        redirect_uri: req.body.redirectUri
    };
    request.get({
        url: accessTokenUrl,
        qs: params,
        json: true
    }, function(err, response, accessToken) {
        console.log("Line 24:", response);
        console.log("Line 25:", accessToken)
        if (response.statusCode !== 200) {
            return res.status(500).send({
                message: accessToken.error.message
            });
        }
        request.get({
            url: graphApiUrl,
            qs: accessToken,
            json: true
        }, function(err, response, profile) {
            console.log("Line 37:", response);
            console.log("Line 38:", profile);
            if (response.statusCode !== 200) {
                return res.status(500).send({
                    message: profile.error.message
                });
            } else {
                registrationModel.findOne({ OAuthID: profile.id }, function(err, result) {
                    if (result) {
                        res.status(200).json({ result: result });
                    } else {

                    }
                })
                dbConfig.db.query("FOR doc IN userCollection FILTER doc.OAuthID == @OAuthID RETURN doc", {
                    "OAuthID": profile.id
                }, function(err, result) {
                    if (result._result.length > 0) {
                        res.json({
                            userKey: result._result[0]._key,
                            registered: true,
                            token: accessToken
                        })
                    } else {
                        var userKey = randtoken.generate(30);
                        var token = randtoken.generate(30);

                        doc = {
                            _key: userKey,
                            email: profile.email,
                            OAuthID: profile.id,
                            OAuthType: 'facebook',
                            isActive: true,
                            registrationCompleted: true
                        };
                        dbConfig.userCollection.save(doc, function(err) {
                            if (!err) {
                                res.json({
                                    userKey: userKey,
                                    email: profile.email,
                                    firstName: profile.first_name,
                                    lastName: profile.last_name,
                                    gender: profile.gender,
                                    profileImage: 'https://graph.facebook.com/' + profile.id + '/picture?type=large',
                                    registered: false,
                                    token: accessToken
                                });
                            }
                        })
                    }
                })
            }
        });
    });
};